bs4.tests package
=================

Submodules
----------

bs4.tests.test_builder_registry module
--------------------------------------

.. automodule:: bs4.tests.test_builder_registry
    :members:
    :undoc-members:
    :show-inheritance:

bs4.tests.test_docs module
--------------------------

.. automodule:: bs4.tests.test_docs
    :members:
    :undoc-members:
    :show-inheritance:

bs4.tests.test_html5lib module
------------------------------

.. automodule:: bs4.tests.test_html5lib
    :members:
    :undoc-members:
    :show-inheritance:

bs4.tests.test_htmlparser module
--------------------------------

.. automodule:: bs4.tests.test_htmlparser
    :members:
    :undoc-members:
    :show-inheritance:

bs4.tests.test_lxml module
--------------------------

.. automodule:: bs4.tests.test_lxml
    :members:
    :undoc-members:
    :show-inheritance:

bs4.tests.test_soup module
--------------------------

.. automodule:: bs4.tests.test_soup
    :members:
    :undoc-members:
    :show-inheritance:

bs4.tests.test_tree module
--------------------------

.. automodule:: bs4.tests.test_tree
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: bs4.tests
    :members:
    :undoc-members:
    :show-inheritance:
